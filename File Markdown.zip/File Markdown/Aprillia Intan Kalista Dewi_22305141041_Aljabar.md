﻿# Aprillia Intan Kalista Dewi_22305141041_Aljabar
Nama : Aprillia Intan Kalista Dewi


NIM  : 22305141041


---

# Pertidaksamaan dan Sistem Pertidaksamaan

## 1. Pertidaksamaan Linear (Pangkat Satu)



a. Pertidaksamaan linear satu variabel


Pertidaksamaan linear satu variabel merupakan bentuk pertidaksamaan
dengan memuat satu peubah (variabel) dengan pangkat tertingginya
adalah satu.


Bentuk umum


$$ax+b < c$$$$ax+b > c$$$$ax+b\le{c}$$$$ax+b\ge{c}$$Contoh soal


Untuk menyelesaikan pertidaksamaan, EMT tidak akan dapat melakukannya,


melainkan dengan bantuan Maxima, artinya secara eksak (simbolik).
Perintah Maxima yang digunakan adalah fourier_elim(), yang harus
dipanggil dengan perintah "load(fourier_elim)" terlebih dahulu.


\>&load(fourier\_elim)


    
           C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/fo\
    urier_elim/fourier_elim.lisp
    

\>$&fourier\_elim([x + 10 \> 0],[x])


$$\left[ -10<x \right] $$\>$&fourier\_elim([2\*x \> 15],[x])


$$\left[ \frac{15}{2}<x \right] $$\>$&fourier\_elim([3\*x - 18 \> 0 ],[x])


$$\left[ 6<x \right] $$---



b. Pertidaksamaan linear dua variabel


Pertidaksamaan linear dua variabel adalah bentuk pertidaksamaan yang
memuat dua peubah (variabel) dengan pangkat tertinggi variabel
tersebut adalah satu.


Bentuk umum


$$ax+by < c$$$$ax+by > c$$$$ax+by\le{c}$$$$ax+by\ge{c}$$Contoh soal


\>$&fourier\_elim((x + y < 5) and (x - y \> 0),[x,y])


$$\left[ y<x , x<5-y , y<\frac{5}{2} \right] $$\>$&fourier\_elim((y - x < 5) and (x - y < 15) and (10 < y),[x,y]) // sistem pertidaksamaan


$$\left[ y-5<x , x<y+15 , 10<y \right] $$\>$&fourier\_elim((x + y < 9) and (x - y \> 7),[x,y])


$$\left[ y+7<x , x<9-y , y<1 \right] $$## 2. Pertidaksamaan Kuadrat



Pertidaksamaan kuadrat ialah pertidaksamaan yang mempunyai variabel
dimana pangkatnya memuat satu atau lebih perubahan serta relasi “lebih
dari”, “lebih dari atau sama dengan”, “kurang dari”, atau “kurang dari
sama dengan”.


Bentuk umum


$$ax^2+bx+c>0$$$$ax^2+bx+c<0$$$$ax^2+bx+c\ge{0}$$$$ax^2+bx+c\le{0}$$---



Contoh soal


\>&load (fourier\_elim)


    
           C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/fo\
    urier_elim/fourier_elim.lisp
    

\>$& fourier\_elim([x^2 + 9\*x + 20 \>= 0], [x])


$$\left[ x=-5 \right] \lor \left[ x=-4 \right] \lor \left[ -4<x
  \right] \lor \left[ x<-5 \right] $$\>$& fourier\_elim([x^2 + 8\*x + 15 \> 0], [x])


$$\left[ -3<x \right] \lor \left[ x<-5 \right] $$\>$& fourier\_elim([x^2 + 6\*x + 9 \> 0], [x])


$$\left[ x<-3 \right] \lor \left[ -3<x \right] $$## 3. Pertidaksamaan Logaritma



Pertidaksamaan logaritma adalah pertidaksamaan yang memuat fungsi
logaritma di dalamnya.


Bentuk umum


$$^a log  f(x) < ^a log  g(x)$$$$^a log  f(x) > ^a log  g(x)$$$$^a log  f(x) \le{^a log  g(x)}$$$$^a log  f(x) \ge{^a log  g(x)}$$Konsep pertidaksamaan logaritma


a) Untuk a &gt; 1, tanda ketaksamaannya tetap (tidak berubah)


b) Untuk a &lt; 1, tanda ketaksamaannya berubah (dibalik)


---



Contoh soal


$$^2 log (x+1) > 3$$$$^2 log (x+1) > ^2log2^3$$\>$&fourier\_elim ([x + 1 \> 8], [x])


$$\left[ 7<x \right] $$$$^\frac{1}{3}log (2x-3) \ge {^\frac{1}{3}log (x+1)}$$\>$&fourier\_elim ([2\*x - 3 \>= x + 1], [x])


$$\left[ x=4 \right] \lor \left[ 4<x \right] $$karena a &lt; 1 maka tanda ketaksamaannya berubah sehingga


$$x \ge{4}$$$$^2log(5x+3) < ^2log(x-2)$$\>$&fourier\_elim ([5\*x + 3 < x - 2], [x])


$$\left[ x<-\frac{5}{4} \right] $$## 4. Pertidaksamaan Trigonometri



Pertidaksamaan trigonometri merupakan pertidaksamaan yang mengandung
fungsi-fungsi trigonometri, baik sinus, cosinus, tangen, cotangen,
secan dan cosecan.


Contoh soal


$$2sinx \le{1}$$\>$& fourier\_elim([2\*sin(x)<=1],[x])


$$\left[ 2\,\sin x-1=0 \right] \lor \left[ 1-2\,\sin x>0 \right] $$\>$& solve (2\*sin(x)-1=0)


$$\left[ x=\frac{\pi}{6} \right] $$$$2cos2x < {1}$$\>$& fourier\_elim([2\*cos(2\*x)< 1],[x])


$$\left[ 1-2\,\cos \left(2\,x\right)>0 \right] $$$$tan x > -1$$\>$& fourier\_elim([tan(x)\> 1],[x])


$$\left[ \tan x-1>0 \right] $$## 5. Pertidaksamaan Eksponen



Eksponen merupakan bentuk penulisan bilangan berpangkat atau perkalian
secara berulang sebanyak pangkatnya. Pertidaksamaan eksponen adalah
bentuk pertidaksamaan pada bilangan berpangkat yang memuat variabel,
seperti x.


Bentuk pertidaksamaan eksponen:


Secara umum, bentuk pertidaksamaan eksponen dibagi menjadi dua, yaitu
sebagai berikut.


a) Jika bilangan pokok a &gt; 1, untuk


$$a^{f(x)} < a^{g(x)} berlaku f(x) < g(x)$$

b) Jika bilangan pokok 0 &lt; a &lt; 1, untuk


$$a^{f(x)} < a^{g(x)} berlaku f(x) > g(x)$$---



Contoh soal


$$27^{x-3} < 81^{x+5}$$ubah bentuk eksponen menjadi basis 3 sehingga


$$3^{3(x-3)} < 3^{4(x+5)}$$$$3^{(3x-9)} < 3^{(4x+20)}$$

karena basis sudah sama, selesaikan menggunakan bantuan emt


\>$&fourier\_elim ([3\*x-9 < 4\*x+20],[x])


$$\left[ -29<x \right] $$$$2^{2x+3} > 8^{x-5}$$

ubah bentuk ekspnen menjadi basis 2 sehingga


$$2^{(2x+3)} < 2^{3(x-5)}$$$$2^{(2x+3)} < 2^{(3x-15)}$$

karena basis sudah sama, selesaikan menggunakan bantuan emt


\>$&fourier\_elim ([2\*x+3 < 3\*x-15],[x])


$$\left[ 18<x \right] $$$$\frac{2}{3}^{5x-7} < \frac{2}{3}^{x-2}$$\>$&fourier\_elim ([5\*x-7 < x+2],[x])


$$\left[ x<\frac{9}{4} \right] $$karena 0 &lt; a &lt; 1, maka tanda pertidaksamaan dibalik. sehingga


$$x > \frac{9}{4}$$